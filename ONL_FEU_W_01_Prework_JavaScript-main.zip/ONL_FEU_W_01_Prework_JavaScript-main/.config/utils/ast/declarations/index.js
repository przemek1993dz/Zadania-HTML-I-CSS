import { variableDeclaration } from "./variableDeclaration";
import { functionDeclaration } from "./functionDeclaration";

export { variableDeclaration, functionDeclaration };
