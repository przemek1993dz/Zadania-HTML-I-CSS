![Coders-Lab-1920px-no-background](https://user-images.githubusercontent.com/30623667/104709394-2cabee80-571f-11eb-9518-ea6a794e558e.png)



Wpisz w pliku `app.js` następującą instrukcję:

```js
console.log("Hello JS");
```

Otwórz plik `index.html` w przeglądarce (najlepiej Chrome) i zajrzyj do konsoli w Chrome Developer Tools. Co się w niej pojawia? Zwróć uwagę, w jaki sposób plik JavaScript został dodany do dokumentu HTML.




Zdefiniuj trzy zmienne (`a`, `b`, i `c`) i wyświetl ich wartości w konsoli przeglądarki.

Np.:

```js
const a = 2; // Zdefiniowanie zmiennej
console.log(a); // Wypisanie wartości
```