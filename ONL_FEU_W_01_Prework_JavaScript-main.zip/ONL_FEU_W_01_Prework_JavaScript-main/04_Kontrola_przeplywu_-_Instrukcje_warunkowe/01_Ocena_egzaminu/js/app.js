const passingScore = 60;
const studentScore = 71;
