![Coders-Lab-1920px-no-background](https://user-images.githubusercontent.com/30623667/104709394-2cabee80-571f-11eb-9518-ea6a794e558e.png)


## Ocena egzaminu

Z wykorzystaniem instrukcji warunkowej `if ... else` wypisz, czy egzamin jest zaliczony. Zrób to na podstawie informacji w zmiennych `passingScore` i `studentScore`.

Egzamin jest zaliczony, gdy uzyskano więcej punktów (`studentScore`) niż określa `passingScore`.

Wyświetlcie napis w konsoli `Exam passed` jeżeli warunek został spełniony bądź `Exam failed` jeżeli ilość punktów (`studentScore`) jest mniejsza niż wartość `passingScore`.


## Ocena literowa

Z wykorzystaniem instrukcji warunkowej `switch` wyświetl odpowiedni tekst w zależności od wartości zmiennej `grade`:

- dla `6` tekst **"A"**
- dla `5` tekst **"B"**
- dla `4` tekst **"C"**
- dla `3` tekst **"D"**
- dla `2` tekst **"E"**
- dla `1` tekst **"F"**

