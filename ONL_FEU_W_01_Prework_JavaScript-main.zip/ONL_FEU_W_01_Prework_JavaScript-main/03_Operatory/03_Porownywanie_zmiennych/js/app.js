const numberAsNumber = 12;
const numberAsString = "12";