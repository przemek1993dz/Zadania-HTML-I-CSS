let startValue;
let finalValue;
// Do not change code above!
