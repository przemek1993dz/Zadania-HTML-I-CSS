const n = 3;
const calc = [];

/**
 * Write your code below!
 */

