const numbers = [];
const columns = 4;
const rows = 5;

/**
 * Write your code below!
 */

