const numbers = [];
const n = 12;

/**
 * Write your code below!
 */

