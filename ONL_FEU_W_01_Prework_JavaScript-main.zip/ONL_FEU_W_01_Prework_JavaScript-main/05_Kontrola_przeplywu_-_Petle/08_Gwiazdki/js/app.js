const n = 5;

/**
 * Write your code below!
 */

