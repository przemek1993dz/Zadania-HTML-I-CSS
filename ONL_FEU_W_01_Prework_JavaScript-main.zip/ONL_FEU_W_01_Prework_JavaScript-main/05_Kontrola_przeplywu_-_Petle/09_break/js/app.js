let i = 0;
while (true) {
  /**
   * Write your code below!
   */


}
