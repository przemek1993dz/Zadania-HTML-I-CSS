const n = 13;

/**
 * Write your code below!
 */

