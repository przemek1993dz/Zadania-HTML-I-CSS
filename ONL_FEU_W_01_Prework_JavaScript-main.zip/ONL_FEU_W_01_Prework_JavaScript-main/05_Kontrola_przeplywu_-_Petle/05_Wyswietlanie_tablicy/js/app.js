const numbers = [
  [16, 32, 2048],
  [64, 256, 1024],
  [8, 2, 4],
];

/**
 * Write your code below!
 */

