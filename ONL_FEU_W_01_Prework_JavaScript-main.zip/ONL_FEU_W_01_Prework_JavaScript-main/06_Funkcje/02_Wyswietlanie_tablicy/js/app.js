const people = ["John", "Ive", "Donna", "Chris"];

/**
 * Write your code below!
 */

/**
 * Do NOT modify code below!
 */
module.exports = typeof printArray === "undefined" ? null : printArray;
